GITHUB SOURCE: https://github.com/Sycnex/Windows10Debloater
POWERSHELL COMMAND: Set-ExecutionPolicy Unrestricted -Force
